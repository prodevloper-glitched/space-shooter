import Foundation

/// Singleton GameManager for native iOS 2D Space Shooter.
/// Tracks coins economy, score, and wave progression with UserDefaults persistence.
public final class GameManager {
    public static let shared = GameManager()

    private let userDefaultsKeyCoins = "shooter_game_saved_coins"

    public private(set) var score: Int = 0
    public private(set) var coins: Int = 0
    public private(set) var currentWave: Int = 1

    private init() {
        coins = UserDefaults.standard.integer(forKey: userDefaultsKeyCoins)
    }

    public func addScore(_ amount: Int) {
        guard amount > 0 else { return }
        score += amount
    }

    public func addCoins(_ amount: Int) {
        guard amount > 0 else { return }
        coins += amount
        UserDefaults.standard.set(coins, forKey: userDefaultsKeyCoins)
    }

    @discardableResult
    public func spendCoins(_ amount: Int) -> Bool {
        guard amount > 0, coins >= amount else { return false }
        coins -= amount
        UserDefaults.standard.set(coins, forKey: userDefaultsKeyCoins)
        return true
    }

    public func setWave(_ wave: Int) {
        currentWave = wave
    }

    public func resetRun() {
        score = 0
        currentWave = 1
    }
}
