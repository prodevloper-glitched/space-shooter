import SpriteKit

/// Game Over modal overlay for iOS SpriteKit.
/// Displays final score, level, enemies defeated, and side-by-side restart & menu buttons.
public final class GameOverNode: SKNode {

    public private(set) var restartButton: SKShapeNode!
    public private(set) var mainMenuButton: SKShapeNode!

    public init(screenSize: CGSize, score: Int, level: Int, kills: Int) {
        super.init()
        self.name = "game_over_menu"
        self.zPosition = 300
        setupModal(screenSize: screenSize, score: score, level: level, kills: kills)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupModal(screenSize: CGSize, score: Int, level: Int, kills: Int) {
        let centerX = screenSize.width / 2.0
        let centerY = screenSize.height / 2.0

        // 1. Dim Backdrop
        let dimLayer = SKSpriteNode(color: UIColor(white: 0.0, alpha: 0.8), size: screenSize)
        dimLayer.position = CGPoint(x: centerX, y: centerY)
        addChild(dimLayer)

        // 2. Centered Card
        let cardW = min(screenSize.width * 0.65, 460.0)
        let cardH = min(screenSize.height * 0.78, 300.0)
        let card = SKShapeNode(rectOf: CGSize(width: cardW, height: cardH), cornerRadius: 18.0)
        card.fillColor = UIColor(red: 0.12, green: 0.05, blue: 0.08, alpha: 0.98)
        card.strokeColor = UIColor(red: 0.95, green: 0.2, blue: 0.2, alpha: 0.9)
        card.lineWidth = 2.5
        card.position = CGPoint(x: centerX, y: centerY)
        addChild(card)

        // 3. Title
        let titleLabel = SKLabelNode(fontNamed: "HelveticaNeue-BlackCondensed")
        titleLabel.text = "GAME OVER"
        titleLabel.fontSize = 32.0
        titleLabel.fontColor = UIColor(red: 1.0, green: 0.25, blue: 0.25, alpha: 1.0)
        titleLabel.position = CGPoint(x: 0, y: cardH * 0.30)
        card.addChild(titleLabel)

        // 4. Run Stats
        let scoreLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        scoreLabel.text = "FINAL SCORE: \(score)"
        scoreLabel.fontSize = 19.0
        scoreLabel.fontColor = .white
        scoreLabel.position = CGPoint(x: 0, y: cardH * 0.12)
        card.addChild(scoreLabel)

        let detailLabel = SKLabelNode(fontNamed: "HelveticaNeue-Medium")
        detailLabel.text = "LEVEL REACHED: \(level)  •  ENEMIES DESTROYED: \(kills)"
        detailLabel.fontSize = 14.0
        detailLabel.fontColor = UIColor(red: 0.7, green: 0.8, blue: 0.9, alpha: 0.9)
        detailLabel.position = CGPoint(x: 0, y: cardH * -0.04)
        card.addChild(detailLabel)

        // 5. Side-by-side Buttons
        let btnW = cardW * 0.42
        let btnH: CGFloat = 46.0

        // Restart Run Button (Left)
        restartButton = SKShapeNode(rectOf: CGSize(width: btnW, height: btnH), cornerRadius: 10.0)
        restartButton.fillColor = UIColor(red: 0.85, green: 0.18, blue: 0.18, alpha: 1.0)
        restartButton.strokeColor = UIColor(red: 1.0, green: 0.45, blue: 0.45, alpha: 0.9)
        restartButton.lineWidth = 2.0
        restartButton.position = CGPoint(x: -cardW * 0.23, y: cardH * -0.28)
        restartButton.name = "btn_restart"
        card.addChild(restartButton)

        let restartLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        restartLabel.text = "↺ RESTART"
        restartLabel.fontSize = 16.0
        restartLabel.fontColor = .white
        restartLabel.verticalAlignmentMode = .center
        restartLabel.name = "btn_restart"
        restartButton.addChild(restartLabel)

        // Main Menu Button (Right)
        mainMenuButton = SKShapeNode(rectOf: CGSize(width: btnW, height: btnH), cornerRadius: 10.0)
        mainMenuButton.fillColor = UIColor(red: 0.15, green: 0.40, blue: 0.85, alpha: 1.0)
        mainMenuButton.strokeColor = UIColor(red: 0.4, green: 0.65, blue: 1.0, alpha: 0.9)
        mainMenuButton.lineWidth = 2.0
        mainMenuButton.position = CGPoint(x: cardW * 0.23, y: cardH * -0.28)
        mainMenuButton.name = "btn_main_menu"
        card.addChild(mainMenuButton)

        let menuLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        menuLabel.text = "⌂ MAIN MENU"
        menuLabel.fontSize = 16.0
        menuLabel.fontColor = .white
        menuLabel.verticalAlignmentMode = .center
        menuLabel.name = "btn_main_menu"
        mainMenuButton.addChild(menuLabel)
    }
}
