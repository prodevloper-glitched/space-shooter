import UIKit
import SpriteKit

/// Host ViewController for iOS 2D Space Shooter.
/// Configures landscape orientation, immersive fullscreen, ProMotion 60/120 FPS rendering,
/// and forwards dynamic safeAreaInsets (Notch / Dynamic Island / Home Bar) to GameScene.
public final class GameViewController: UIViewController {

    private var gameScene: GameScene?

    public override func loadView() {
        self.view = SKView()
    }

    public override func viewDidLoad() {
        super.viewDidLoad()

        guard let skView = self.view as? SKView else { return }

        // Optimize rendering performance
        skView.ignoresSiblingOrder = true
        skView.showsFPS = false
        skView.showsNodeCount = false

        // Initialize Audio
        _ = AudioManager.shared
    }

    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        guard let skView = self.view as? SKView else { return }

        if gameScene == nil && skView.bounds.size.width > 0 && skView.bounds.size.height > 0 {
            let scene = GameScene(size: skView.bounds.size)
            scene.scaleMode = .resizeFill
            scene.safeAreaInsets = view.safeAreaInsets
            skView.presentScene(scene)
            self.gameScene = scene
        } else if let scene = gameScene {
            scene.size = skView.bounds.size
            scene.safeAreaInsets = view.safeAreaInsets
        }
    }

    public override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        gameScene?.safeAreaInsets = view.safeAreaInsets
    }

    public override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }

    public override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return .landscapeRight
    }

    public override var prefersStatusBarHidden: Bool {
        return true
    }

    public override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
}
