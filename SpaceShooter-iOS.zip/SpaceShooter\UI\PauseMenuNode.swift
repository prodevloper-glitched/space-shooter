import SpriteKit

/// Pause Menu modal overlay for iOS SpriteKit.
/// Offers three options:
/// - RESUME: Unpauses and resumes combat immediately
/// - RESTART RUN: Resets wave, score, and player state to Level 1
/// - MAIN MENU: Returns to the Start Screen
public final class PauseMenuNode: SKNode {

    public private(set) var resumeButton: SKShapeNode!
    public private(set) var restartButton: SKShapeNode!
    public private(set) var mainMenuButton: SKShapeNode!

    public init(screenSize: CGSize) {
        super.init()
        self.name = "pause_menu"
        self.zPosition = 300
        setupModal(screenSize: screenSize)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupModal(screenSize: CGSize) {
        let centerX = screenSize.width / 2.0
        let centerY = screenSize.height / 2.0

        // 1. Dim Backdrop
        let dimLayer = SKSpriteNode(color: UIColor(white: 0.0, alpha: 0.75), size: screenSize)
        dimLayer.position = CGPoint(x: centerX, y: centerY)
        addChild(dimLayer)

        // 2. Centered Card
        let cardW = min(screenSize.width * 0.55, 380.0)
        let cardH = min(screenSize.height * 0.75, 290.0)
        let card = SKShapeNode(rectOf: CGSize(width: cardW, height: cardH), cornerRadius: 16.0)
        card.fillColor = UIColor(red: 0.08, green: 0.12, blue: 0.22, alpha: 0.96)
        card.strokeColor = UIColor(red: 0.0, green: 0.8, blue: 1.0, alpha: 0.9)
        card.lineWidth = 2.5
        card.position = CGPoint(x: centerX, y: centerY)
        addChild(card)

        // 3. Title
        let titleLabel = SKLabelNode(fontNamed: "HelveticaNeue-BlackCondensed")
        titleLabel.text = "GAME PAUSED"
        titleLabel.fontSize = 28.0
        titleLabel.fontColor = .white
        titleLabel.position = CGPoint(x: 0, y: cardH * 0.32)
        card.addChild(titleLabel)

        // 4. Buttons
        let btnW = cardW * 0.78
        let btnH: CGFloat = 46.0

        // Resume Button (Green)
        resumeButton = SKShapeNode(rectOf: CGSize(width: btnW, height: btnH), cornerRadius: 10.0)
        resumeButton.fillColor = UIColor(red: 0.0, green: 0.75, blue: 0.35, alpha: 1.0)
        resumeButton.strokeColor = UIColor(red: 0.2, green: 0.95, blue: 0.55, alpha: 0.8)
        resumeButton.lineWidth = 2.0
        resumeButton.position = CGPoint(x: 0, y: cardH * 0.08)
        resumeButton.name = "btn_resume"
        card.addChild(resumeButton)

        let resumeLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        resumeLabel.text = "▶ RESUME"
        resumeLabel.fontSize = 17.0
        resumeLabel.fontColor = .white
        resumeLabel.verticalAlignmentMode = .center
        resumeLabel.name = "btn_resume"
        resumeButton.addChild(resumeLabel)

        // Restart Run Button (Red)
        restartButton = SKShapeNode(rectOf: CGSize(width: btnW, height: btnH), cornerRadius: 10.0)
        restartButton.fillColor = UIColor(red: 0.85, green: 0.18, blue: 0.18, alpha: 1.0)
        restartButton.strokeColor = UIColor(red: 1.0, green: 0.4, blue: 0.4, alpha: 0.8)
        restartButton.lineWidth = 2.0
        restartButton.position = CGPoint(x: 0, y: cardH * -0.12)
        restartButton.name = "btn_restart"
        card.addChild(restartButton)

        let restartLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        restartLabel.text = "↺ RESTART RUN"
        restartLabel.fontSize = 17.0
        restartLabel.fontColor = .white
        restartLabel.verticalAlignmentMode = .center
        restartLabel.name = "btn_restart"
        restartButton.addChild(restartLabel)

        // Main Menu Button (Blue)
        mainMenuButton = SKShapeNode(rectOf: CGSize(width: btnW, height: btnH), cornerRadius: 10.0)
        mainMenuButton.fillColor = UIColor(red: 0.15, green: 0.40, blue: 0.85, alpha: 1.0)
        mainMenuButton.strokeColor = UIColor(red: 0.4, green: 0.65, blue: 1.0, alpha: 0.8)
        mainMenuButton.lineWidth = 2.0
        mainMenuButton.position = CGPoint(x: 0, y: cardH * -0.32)
        mainMenuButton.name = "btn_main_menu"
        card.addChild(mainMenuButton)

        let menuLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        menuLabel.text = "⌂ MAIN MENU"
        menuLabel.fontSize = 17.0
        menuLabel.fontColor = .white
        menuLabel.verticalAlignmentMode = .center
        menuLabel.name = "btn_main_menu"
        mainMenuButton.addChild(menuLabel)
    }
}
