import SpriteKit

/// Bullet projectile for iOS 2D Space Shooter.
/// Moves upward and is removed immediately upon exiting the top of the screen (y >= scene.size.height),
/// preventing memory leaks and off-screen entity buildup.
public final class BulletNode: SKNode {
    public let damage: Int
    public let speedValue: CGFloat = 1500.0

    public init(damage: Int) {
        self.damage = damage
        super.init()
        self.name = "bullet"
        setupVisuals()
        setupPhysics()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupVisuals() {
        let radius: CGFloat = 10.0

        // Golden Plasma Aura
        let auraRect = CGRect(x: -radius, y: -radius * 1.8, width: radius * 2.0, height: radius * 3.6)
        let aura = SKShapeNode(rect: auraRect, cornerRadius: radius)
        aura.fillColor = UIColor(red: 1.0, green: 0.78, blue: 0.0, alpha: 0.85) // Golden Plasma
        aura.strokeColor = UIColor(red: 1.0, green: 0.6, blue: 0.0, alpha: 0.9)
        aura.lineWidth = 1.5
        addChild(aura)

        // Bright White-Yellow Core
        let coreRect = CGRect(x: -radius * 0.5, y: -radius * 1.2, width: radius, height: radius * 2.4)
        let core = SKShapeNode(rect: coreRect, cornerRadius: radius * 0.5)
        core.fillColor = UIColor(red: 1.0, green: 1.0, blue: 0.8, alpha: 1.0)
        core.strokeColor = .clear
        addChild(core)
    }

    private func setupPhysics() {
        let bodySize = CGSize(width: 18, height: 32)
        let body = SKPhysicsBody(rectangleOf: bodySize)
        body.isDynamic = true
        body.categoryBitMask = PhysicsCategory.bullet
        body.contactTestBitMask = PhysicsCategory.enemy
        body.collisionBitMask = PhysicsCategory.none
        body.affectedByGravity = false
        self.physicsBody = body
    }

    public func update(deltaTime: TimeInterval, topBoundary: CGFloat) {
        position.y += speedValue * CGFloat(deltaTime)
        if position.y - 20 >= topBoundary {
            removeFromParent()
        }
    }
}
