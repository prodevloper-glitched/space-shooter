import SpriteKit

/// Upgrade Shop modal overlay for iOS SpriteKit.
/// Formatted into a responsive 3-column layout for horizontal landscape displays.
/// Allows purchasing upgrades for 1) Damage, 2) Fire Rate, and 3) Max Health.
public final class ShopNode: SKNode {

    public private(set) var buyDamageButton: SKShapeNode!
    public private(set) var buyFireRateButton: SKShapeNode!
    public private(set) var buyHealthButton: SKShapeNode!
    public private(set) var nextLevelButton: SKShapeNode!
    public private(set) var mainMenuButton: SKShapeNode!

    private var balanceLabel: SKLabelNode!
    private var damageCostLabel: SKLabelNode!
    private var fireRateCostLabel: SKLabelNode!
    private var healthCostLabel: SKLabelNode!
    private var damageLvlLabel: SKLabelNode!
    private var fireRateLvlLabel: SKLabelNode!
    private var healthLvlLabel: SKLabelNode!

    public init(screenSize: CGSize, completedLevel: Int, bonusCoins: Int) {
        super.init()
        self.name = "shop_menu"
        self.zPosition = 300
        setupModal(screenSize: screenSize, completedLevel: completedLevel, bonusCoins: bonusCoins)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupModal(screenSize: CGSize, completedLevel: Int, bonusCoins: Int) {
        let centerX = screenSize.width / 2.0
        let centerY = screenSize.height / 2.0

        // 1. Dim Backdrop
        let dimLayer = SKSpriteNode(color: UIColor(white: 0.0, alpha: 0.82), size: screenSize)
        dimLayer.position = CGPoint(x: centerX, y: centerY)
        addChild(dimLayer)

        // 2. Main Outer Card
        let cardW = min(screenSize.width * 0.88, 680.0)
        let cardH = min(screenSize.height * 0.84, 330.0)
        let card = SKShapeNode(rectOf: CGSize(width: cardW, height: cardH), cornerRadius: 18.0)
        card.fillColor = UIColor(red: 0.06, green: 0.10, blue: 0.18, alpha: 0.98)
        card.strokeColor = UIColor(red: 0.0, green: 0.85, blue: 1.0, alpha: 0.85)
        card.lineWidth = 2.5
        card.position = CGPoint(x: centerX, y: centerY)
        addChild(card)

        // 3. Header
        let titleLabel = SKLabelNode(fontNamed: "HelveticaNeue-BlackCondensed")
        titleLabel.text = "LEVEL \(completedLevel) CLEARED!"
        titleLabel.fontSize = 24.0
        titleLabel.fontColor = UIColor(red: 0.0, green: 0.9, blue: 0.45, alpha: 1.0)
        titleLabel.position = CGPoint(x: 0, y: cardH * 0.36)
        card.addChild(titleLabel)

        let bonusLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        bonusLabel.text = "BONUS REWARD: +\(bonusCoins) COINS"
        bonusLabel.fontSize = 14.0
        bonusLabel.fontColor = UIColor(red: 1.0, green: 0.84, blue: 0.0, alpha: 1.0)
        bonusLabel.position = CGPoint(x: 0, y: cardH * 0.26)
        card.addChild(bonusLabel)

        balanceLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        balanceLabel.fontSize = 15.0
        balanceLabel.fontColor = .white
        balanceLabel.position = CGPoint(x: 0, y: cardH * 0.17)
        card.addChild(balanceLabel)

        // 4. 3-Column Upgrades Grid
        let colW = cardW * 0.28
        let colH = cardH * 0.44
        let colY = cardH * -0.07

        // --- Column 1: Damage ---
        let col1X = -cardW * 0.31
        let damageCard = SKShapeNode(rectOf: CGSize(width: colW, height: colH), cornerRadius: 10.0)
        damageCard.fillColor = UIColor(red: 0.10, green: 0.14, blue: 0.24, alpha: 0.9)
        damageCard.strokeColor = UIColor(red: 0.2, green: 0.4, blue: 0.7, alpha: 0.6)
        damageCard.position = CGPoint(x: col1X, y: colY)
        card.addChild(damageCard)

        let dmgTitle = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        dmgTitle.text = "⚡ DAMAGE"
        dmgTitle.fontSize = 14.0
        dmgTitle.fontColor = UIColor(red: 0.4, green: 0.75, blue: 1.0, alpha: 1.0)
        dmgTitle.position = CGPoint(x: 0, y: colH * 0.26)
        damageCard.addChild(dmgTitle)

        damageLvlLabel = SKLabelNode(fontNamed: "HelveticaNeue-Medium")
        damageLvlLabel.fontSize = 12.0
        damageLvlLabel.fontColor = .white
        damageLvlLabel.position = CGPoint(x: 0, y: colH * 0.06)
        damageCard.addChild(damageLvlLabel)

        buyDamageButton = SKShapeNode(rectOf: CGSize(width: colW * 0.85, height: 32.0), cornerRadius: 6.0)
        buyDamageButton.fillColor = UIColor(red: 0.15, green: 0.50, blue: 0.20, alpha: 1.0)
        buyDamageButton.position = CGPoint(x: 0, y: colH * -0.28)
        buyDamageButton.name = "btn_buy_damage"
        damageCard.addChild(buyDamageButton)

        damageCostLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        damageCostLabel.fontSize = 12.0
        damageCostLabel.fontColor = .white
        damageCostLabel.verticalAlignmentMode = .center
        damageCostLabel.name = "btn_buy_damage"
        buyDamageButton.addChild(damageCostLabel)

        // --- Column 2: Fire Rate ---
        let col2X: CGFloat = 0
        let fireRateCard = SKShapeNode(rectOf: CGSize(width: colW, height: colH), cornerRadius: 10.0)
        fireRateCard.fillColor = UIColor(red: 0.10, green: 0.14, blue: 0.24, alpha: 0.9)
        fireRateCard.strokeColor = UIColor(red: 0.2, green: 0.4, blue: 0.7, alpha: 0.6)
        fireRateCard.position = CGPoint(x: col2X, y: colY)
        card.addChild(fireRateCard)

        let frTitle = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        frTitle.text = "🔥 FIRE RATE"
        frTitle.fontSize = 14.0
        frTitle.fontColor = UIColor(red: 1.0, green: 0.7, blue: 0.2, alpha: 1.0)
        frTitle.position = CGPoint(x: 0, y: colH * 0.26)
        fireRateCard.addChild(frTitle)

        fireRateLvlLabel = SKLabelNode(fontNamed: "HelveticaNeue-Medium")
        fireRateLvlLabel.fontSize = 12.0
        fireRateLvlLabel.fontColor = .white
        fireRateLvlLabel.position = CGPoint(x: 0, y: colH * 0.06)
        fireRateCard.addChild(fireRateLvlLabel)

        buyFireRateButton = SKShapeNode(rectOf: CGSize(width: colW * 0.85, height: 32.0), cornerRadius: 6.0)
        buyFireRateButton.fillColor = UIColor(red: 0.15, green: 0.50, blue: 0.20, alpha: 1.0)
        buyFireRateButton.position = CGPoint(x: 0, y: colH * -0.28)
        buyFireRateButton.name = "btn_buy_firerate"
        fireRateCard.addChild(buyFireRateButton)

        fireRateCostLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        fireRateCostLabel.fontSize = 12.0
        fireRateCostLabel.fontColor = .white
        fireRateCostLabel.verticalAlignmentMode = .center
        fireRateCostLabel.name = "btn_buy_firerate"
        buyFireRateButton.addChild(fireRateCostLabel)

        // --- Column 3: Max Health ---
        let col3X = cardW * 0.31
        let healthCard = SKShapeNode(rectOf: CGSize(width: colW, height: colH), cornerRadius: 10.0)
        healthCard.fillColor = UIColor(red: 0.10, green: 0.14, blue: 0.24, alpha: 0.9)
        healthCard.strokeColor = UIColor(red: 0.2, green: 0.4, blue: 0.7, alpha: 0.6)
        healthCard.position = CGPoint(x: col3X, y: colY)
        card.addChild(healthCard)

        let hpTitle = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        hpTitle.text = "❤️ MAX HP"
        hpTitle.fontSize = 14.0
        hpTitle.fontColor = UIColor(red: 0.2, green: 0.9, blue: 0.45, alpha: 1.0)
        hpTitle.position = CGPoint(x: 0, y: colH * 0.26)
        healthCard.addChild(hpTitle)

        healthLvlLabel = SKLabelNode(fontNamed: "HelveticaNeue-Medium")
        healthLvlLabel.fontSize = 12.0
        healthLvlLabel.fontColor = .white
        healthLvlLabel.position = CGPoint(x: 0, y: colH * 0.06)
        healthCard.addChild(healthLvlLabel)

        buyHealthButton = SKShapeNode(rectOf: CGSize(width: colW * 0.85, height: 32.0), cornerRadius: 6.0)
        buyHealthButton.fillColor = UIColor(red: 0.15, green: 0.50, blue: 0.20, alpha: 1.0)
        buyHealthButton.position = CGPoint(x: 0, y: colH * -0.28)
        buyHealthButton.name = "btn_buy_health"
        healthCard.addChild(buyHealthButton)

        healthCostLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        healthCostLabel.fontSize = 12.0
        healthCostLabel.fontColor = .white
        healthCostLabel.verticalAlignmentMode = .center
        healthCostLabel.name = "btn_buy_health"
        buyHealthButton.addChild(healthCostLabel)

        // 5. Navigation Buttons Below (Side-by-Side)
        let navBtnW = cardW * 0.38
        let navBtnH: CGFloat = 40.0
        let navY = cardH * -0.38

        // Next Level Button (Left)
        nextLevelButton = SKShapeNode(rectOf: CGSize(width: navBtnW, height: navBtnH), cornerRadius: 8.0)
        nextLevelButton.fillColor = UIColor(red: 0.0, green: 0.75, blue: 0.35, alpha: 1.0)
        nextLevelButton.strokeColor = UIColor(red: 0.2, green: 1.0, blue: 0.5, alpha: 0.8)
        nextLevelButton.lineWidth = 1.5
        nextLevelButton.position = CGPoint(x: -cardW * 0.22, y: navY)
        nextLevelButton.name = "btn_next_level"
        card.addChild(nextLevelButton)

        let nextLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        nextLabel.text = "NEXT LEVEL ➔"
        nextLabel.fontSize = 15.0
        nextLabel.fontColor = .white
        nextLabel.verticalAlignmentMode = .center
        nextLabel.name = "btn_next_level"
        nextLevelButton.addChild(nextLabel)

        // Main Menu Button (Right)
        mainMenuButton = SKShapeNode(rectOf: CGSize(width: navBtnW, height: navBtnH), cornerRadius: 8.0)
        mainMenuButton.fillColor = UIColor(red: 0.15, green: 0.38, blue: 0.80, alpha: 1.0)
        mainMenuButton.strokeColor = UIColor(red: 0.4, green: 0.65, blue: 1.0, alpha: 0.8)
        mainMenuButton.lineWidth = 1.5
        mainMenuButton.position = CGPoint(x: cardW * 0.22, y: navY)
        mainMenuButton.name = "btn_main_menu"
        card.addChild(mainMenuButton)

        let menuLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        menuLabel.text = "⌂ MAIN MENU"
        menuLabel.fontSize = 15.0
        menuLabel.fontColor = .white
        menuLabel.verticalAlignmentMode = .center
        menuLabel.name = "btn_main_menu"
        mainMenuButton.addChild(menuLabel)

        refreshView()
    }

    public func refreshView() {
        let coins = GameManager.shared.coins
        balanceLabel.text = "COINS BALANCE: \(coins) 🪙"

        // Damage
        let dmgLvl = UpgradeManager.shared.damageLevel
        let dmgCost = UpgradeManager.shared.getDamageCost()
        damageLvlLabel.text = "Lvl \(dmgLvl) (Power \(UpgradeManager.shared.currentDamage))"
        if dmgCost > 0 {
            damageCostLabel.text = "BUY (\(dmgCost) 🪙)"
            buyDamageButton.fillColor = (coins >= dmgCost) ? UIColor(red: 0.15, green: 0.60, blue: 0.25, alpha: 1.0) : UIColor.gray
        } else {
            damageCostLabel.text = "MAX LEVEL"
            buyDamageButton.fillColor = UIColor.darkGray
        }

        // Fire Rate
        let frLvl = UpgradeManager.shared.fireRateLevel
        let frCost = UpgradeManager.shared.getFireRateCost()
        let frMs = Int(UpgradeManager.shared.currentFireIntervalSec * 1000)
        fireRateLvlLabel.text = "Lvl \(frLvl) (\(frMs)ms)"
        if frCost > 0 {
            fireRateCostLabel.text = "BUY (\(frCost) 🪙)"
            buyFireRateButton.fillColor = (coins >= frCost) ? UIColor(red: 0.15, green: 0.60, blue: 0.25, alpha: 1.0) : UIColor.gray
        } else {
            fireRateCostLabel.text = "MAX LEVEL"
            buyFireRateButton.fillColor = UIColor.darkGray
        }

        // Health
        let hpLvl = UpgradeManager.shared.healthLevel
        let hpCost = UpgradeManager.shared.getHealthCost()
        healthLvlLabel.text = "Lvl \(hpLvl) (\(UpgradeManager.shared.currentMaxHealth) HP)"
        if hpCost > 0 {
            healthCostLabel.text = "BUY (\(hpCost) 🪙)"
            buyHealthButton.fillColor = (coins >= hpCost) ? UIColor(red: 0.15, green: 0.60, blue: 0.25, alpha: 1.0) : UIColor.gray
        } else {
            healthCostLabel.text = "MAX LEVEL"
            buyHealthButton.fillColor = UIColor.darkGray
        }
    }
}
