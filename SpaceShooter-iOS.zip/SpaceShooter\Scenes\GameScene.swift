import SpriteKit
import UIKit

/// Main GameScene for native iOS 2D Space Shooter.
/// Manages the 60/120 FPS game loop, physics collisions, responsive safe-area layout,
/// audio triggers, and the state machine across Start, Playing, Paused, Shop, and GameOver.
public final class GameScene: SKScene, SKPhysicsContactDelegate {

    public enum GameState {
        case startScreen
        case playing
        case paused
        case shop
        case gameOver
    }

    public private(set) var gameState: GameState = .startScreen

    // Core Nodes
    private var backgroundNode: SpaceBackgroundNode!
    private var playerNode: PlayerNode!
    private var hudNode: HUDNode!

    // Overlays
    private var startMenuNode: StartMenuNode?
    private var pauseMenuNode: PauseMenuNode?
    private var gameOverNode: GameOverNode?
    private var shopNode: ShopNode?

    // Safe Area Insets (Configured dynamically from GameViewController)
    public var safeAreaInsets: UIEdgeInsets = UIEdgeInsets(top: 24, left: 44, bottom: 20, right: 44) {
        didSet {
            updateSafeBounds()
        }
    }

    private var safeMinX: CGFloat = 44.0
    private var safeMaxX: CGFloat = 800.0
    private var safeMinY: CGFloat = 20.0
    private var safeMaxY: CGFloat = 370.0

    // Time & Spawner State
    private var lastUpdateTime: TimeInterval = 0
    private var spawnTimer: TimeInterval = 0
    private var spawnInterval: TimeInterval = 1.0
    private var enemiesToSpawnInWave: Int = 8
    private var enemiesSpawnedInWave: Int = 0

    // Touch Dragging State
    private var isDraggingPlayer = false
    private var activeTouch: UITouch?
    private var dragTouchOffset: CGPoint = .zero

    // Entity Containers
    private let bulletContainer = SKNode()
    private let enemyContainer = SKNode()
    private let coinContainer = SKNode()

    public override func didMove(to view: SKView) {
        physicsWorld.gravity = .zero
        physicsWorld.contactDelegate = self

        setupScene()
        updateSafeBounds()
        showStartScreen()
    }

    private func setupScene() {
        removeAllChildren()

        // 1. Background
        backgroundNode = SpaceBackgroundNode(size: size)
        addChild(backgroundNode)

        // 2. Containers
        addChild(coinContainer)
        addChild(enemyContainer)
        addChild(bulletContainer)

        // 3. Player
        playerNode = PlayerNode()
        let startPos = CGPoint(x: size.width / 2.0, y: size.height * 0.22)
        playerNode.position = startPos
        playerNode.targetPosition = startPos
        addChild(playerNode)

        // 4. HUD
        hudNode = HUDNode()
        addChild(hudNode)
    }

    public func updateSafeBounds() {
        safeMinX = max(safeAreaInsets.left, 44.0)
        safeMaxX = size.width - max(safeAreaInsets.right, 44.0)
        safeMinY = max(safeAreaInsets.bottom, 20.0)
        safeMaxY = size.height - max(safeAreaInsets.top, 24.0)

        hudNode?.updateLayout(screenSize: size, safeInsets: safeAreaInsets)
    }

    // MARK: - Game State Transitions

    public func showStartScreen() {
        gameState = .startScreen
        clearActiveCombatEntities()

        let startPos = CGPoint(x: size.width / 2.0, y: size.height * 0.22)
        playerNode.reset(to: startPos)
        playerNode.isHidden = true
        hudNode.isHidden = true

        dismissAllModals()
        let menu = StartMenuNode(screenSize: size)
        addChild(menu)
        startMenuNode = menu
    }

    public func startNewGame() {
        gameState = .playing
        dismissAllModals()

        GameManager.shared.resetRun()
        LevelManager.shared.startLevel(1)

        applyPlayerUpgrades()
        let startPos = CGPoint(x: size.width / 2.0, y: size.height * 0.22)
        playerNode.reset(to: startPos)
        playerNode.isHidden = false
        hudNode.isHidden = false

        clearActiveCombatEntities()
        resetWaveSpawner()
        updateHUD()
    }

    public func pauseGame() {
        guard gameState == .playing else { return }
        gameState = .paused

        let pauseMenu = PauseMenuNode(screenSize: size)
        addChild(pauseMenu)
        pauseMenuNode = pauseMenu
    }

    public func resumeGame() {
        guard gameState == .paused else { return }
        dismissAllModals()
        gameState = .playing
    }

    public func triggerGameOver() {
        gameState = .gameOver
        clearActiveCombatEntities()
        playerNode.isHidden = true

        let gameOver = GameOverNode(
            screenSize: size,
            score: GameManager.shared.score,
            level: LevelManager.shared.currentLevel,
            kills: LevelManager.shared.currentKills
        )
        addChild(gameOver)
        gameOverNode = gameOver
    }

    public func showUpgradeShop(completedLevel: Int, bonusCoins: Int) {
        gameState = .shop
        clearActiveCombatEntities()

        let shop = ShopNode(screenSize: size, completedLevel: completedLevel, bonusCoins: bonusCoins)
        addChild(shop)
        shopNode = shop
    }

    public func proceedToNextLevel() {
        LevelManager.shared.proceedToNextLevel()
        dismissAllModals()
        applyPlayerUpgrades()

        let startPos = CGPoint(x: size.width / 2.0, y: size.height * 0.22)
        playerNode.reset(to: startPos)
        playerNode.isHidden = false
        hudNode.isHidden = false

        resetWaveSpawner()
        gameState = .playing
        updateHUD()
    }

    private func applyPlayerUpgrades() {
        playerNode.applyUpgrades(
            damage: UpgradeManager.shared.currentDamage,
            fireInterval: UpgradeManager.shared.currentFireIntervalSec,
            maxHp: UpgradeManager.shared.currentMaxHealth
        )
    }

    private func resetWaveSpawner() {
        enemiesSpawnedInWave = 0
        enemiesToSpawnInWave = 8 + (LevelManager.shared.currentLevel - 1) * 3
        spawnTimer = 0
        let reduction = TimeInterval(LevelManager.shared.getSpawnIntervalReduction())
        spawnInterval = max(0.40, 1.05 - reduction)
    }

    private func clearActiveCombatEntities() {
        bulletContainer.removeAllChildren()
        enemyContainer.removeAllChildren()
        coinContainer.removeAllChildren()
        isDraggingPlayer = false
        activeTouch = nil
    }

    private func dismissAllModals() {
        startMenuNode?.removeFromParent()
        startMenuNode = nil
        pauseMenuNode?.removeFromParent()
        pauseMenuNode = nil
        gameOverNode?.removeFromParent()
        gameOverNode = nil
        shopNode?.removeFromParent()
        shopNode = nil
    }

    private func updateHUD() {
        hudNode.update(
            currentHealth: playerNode.currentHealth,
            maxHealth: playerNode.maxHealth,
            score: GameManager.shared.score,
            level: LevelManager.shared.currentLevel,
            coins: GameManager.shared.coins
        )
    }

    // MARK: - Game Loop Update

    public override func update(_ currentTime: TimeInterval) {
        if lastUpdateTime == 0 {
            lastUpdateTime = currentTime
            return
        }
        let deltaTime = currentTime - lastUpdateTime
        lastUpdateTime = currentTime

        // Parallax background always animates smoothly across all game screens
        backgroundNode.update(deltaTime: deltaTime)

        guard gameState == .playing else { return }

        // 1. Update Player
        playerNode.update(
            currentTime: currentTime,
            safeMinX: safeMinX,
            safeMaxX: safeMaxX,
            safeMinY: safeMinY,
            safeMaxY: safeMaxY
        ) { [weak self] muzzlePos, damage in
            self?.fireBullet(from: muzzlePos, damage: damage)
        }

        // 2. Update Bullets
        for child in bulletContainer.children {
            if let bullet = child as? BulletNode {
                bullet.update(deltaTime: deltaTime, topBoundary: size.height)
            }
        }

        // 3. Update Enemies
        for child in enemyContainer.children {
            if let enemy = child as? EnemyNode {
                enemy.update(deltaTime: deltaTime, bottomBoundary: 0)
            }
        }

        // 4. Update Coins
        for child in coinContainer.children {
            if let coin = child as? CoinNode {
                coin.update(deltaTime: deltaTime, playerPosition: playerNode.position, bottomBoundary: 0)
            }
        }

        // 5. Spawn Enemies
        spawnTimer += deltaTime
        if spawnTimer >= spawnInterval && enemiesSpawnedInWave < enemiesToSpawnInWave {
            spawnTimer = 0
            spawnEnemy()
            enemiesSpawnedInWave += 1
        }

        updateHUD()
    }

    private func fireBullet(from position: CGPoint, damage: Int) {
        let bullet = BulletNode(damage: damage)
        bullet.position = position
        bulletContainer.addChild(bullet)
        AudioManager.shared.playLaser()
    }

    private func spawnEnemy() {
        let spawnPadding: CGFloat = 60.0
        let spawnX = CGFloat.random(in: (safeMinX + spawnPadding)...(safeMaxX - spawnPadding))
        let spawnY = size.height + 60.0

        let speedMultiplier = CGFloat(LevelManager.shared.getSpeedMultiplier())
        let enemySpeed = CGFloat.random(in: 230.0...280.0) * speedMultiplier
        let enemyHealth = 2 + (LevelManager.shared.currentLevel - 1) / 2

        let enemy = EnemyNode(maxHealth: enemyHealth, speed: enemySpeed)
        enemy.position = CGPoint(x: spawnX, y: spawnY)
        enemyContainer.addChild(enemy)
    }

    private func spawnCoin(at position: CGPoint) {
        let coin = CoinNode()
        coin.position = position
        coinContainer.addChild(coin)
    }

    // MARK: - Physics Contact Delegate

    public func didBegin(_ contact: SKPhysicsContact) {
        guard gameState == .playing else { return }

        let maskA = contact.bodyA.categoryBitMask
        let maskB = contact.bodyB.categoryBitMask
        let nodeA = contact.bodyA.node
        let nodeB = contact.bodyB.node

        // 1. Bullet vs Enemy
        if (maskA == PhysicsCategory.bullet && maskB == PhysicsCategory.enemy) ||
           (maskA == PhysicsCategory.enemy && maskB == PhysicsCategory.bullet) {
            let bulletNode = (maskA == PhysicsCategory.bullet ? nodeA : nodeB) as? BulletNode
            let enemyNode = (maskA == PhysicsCategory.enemy ? nodeA : nodeB) as? EnemyNode

            if let bullet = bulletNode, let enemy = enemyNode, !enemy.isDestroyed {
                bullet.removeFromParent()
                let wasDestroyed = enemy.takeDamage(bullet.damage)
                if wasDestroyed {
                    handleEnemyDestroyed(enemy)
                }
            }
            return
        }

        // 2. Player vs Enemy
        if (maskA == PhysicsCategory.player && maskB == PhysicsCategory.enemy) ||
           (maskA == PhysicsCategory.enemy && maskB == PhysicsCategory.player) {
            let enemyNode = (maskA == PhysicsCategory.enemy ? nodeA : nodeB) as? EnemyNode

            if let enemy = enemyNode, !enemy.isDestroyed {
                enemy.isDestroyed = true
                enemy.removeFromParent()
                AudioManager.shared.playExplosion()

                let died = playerNode.takeDamage(1)
                updateHUD()
                if died {
                    triggerGameOver()
                }
            }
            return
        }

        // 3. Player vs Coin
        if (maskA == PhysicsCategory.player && maskB == PhysicsCategory.coin) ||
           (maskA == PhysicsCategory.coin && maskB == PhysicsCategory.player) {
            let coinNode = (maskA == PhysicsCategory.coin ? nodeA : nodeB) as? CoinNode
            if let coin = coinNode {
                GameManager.shared.addCoins(coin.value)
                AudioManager.shared.playCoin()
                coin.removeFromParent()
                updateHUD()
            }
            return
        }
    }

    private func handleEnemyDestroyed(_ enemy: EnemyNode) {
        AudioManager.shared.playExplosion()
        GameManager.shared.addScore(enemy.scoreValue)
        spawnCoin(at: enemy.position)
        enemy.removeFromParent()

        LevelManager.shared.registerEnemyKill { [weak self] completedLevel, bonusCoins in
            self?.showUpgradeShop(completedLevel: completedLevel, bonusCoins: bonusCoins)
        }
        updateHUD()
    }

    // MARK: - Touch Handling

    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let touchLocation = touch.location(in: self)
        let touchedNodes = nodes(at: touchLocation)

        // Check Button Taps across states
        for node in touchedNodes {
            if let name = node.name {
                switch name {
                case "btn_start_game":
                    AudioManager.shared.playClick()
                    startNewGame()
                    return
                case "btn_pause":
                    AudioManager.shared.playClick()
                    pauseGame()
                    return
                case "btn_resume":
                    AudioManager.shared.playClick()
                    resumeGame()
                    return
                case "btn_restart":
                    AudioManager.shared.playClick()
                    startNewGame()
                    return
                case "btn_main_menu":
                    AudioManager.shared.playClick()
                    showStartScreen()
                    return
                case "btn_next_level":
                    AudioManager.shared.playClick()
                    proceedToNextLevel()
                    return
                case "btn_buy_damage":
                    if UpgradeManager.shared.tryBuyDamage() {
                        AudioManager.shared.playCoin()
                        applyPlayerUpgrades()
                        shopNode?.refreshView()
                    } else {
                        AudioManager.shared.playClick()
                    }
                    return
                case "btn_buy_firerate":
                    if UpgradeManager.shared.tryBuyFireRate() {
                        AudioManager.shared.playCoin()
                        applyPlayerUpgrades()
                        shopNode?.refreshView()
                    } else {
                        AudioManager.shared.playClick()
                    }
                    return
                case "btn_buy_health":
                    if UpgradeManager.shared.tryBuyHealth() {
                        AudioManager.shared.playCoin()
                        applyPlayerUpgrades()
                        shopNode?.refreshView()
                    } else {
                        AudioManager.shared.playClick()
                    }
                    return
                default:
                    break
                }
            }
        }

        // Gameplay Touch-Drag Movement
        if gameState == .playing && activeTouch == nil {
            activeTouch = touch
            isDraggingPlayer = true
            dragTouchOffset = CGPoint(
                x: playerNode.position.x - touchLocation.x,
                y: playerNode.position.y - touchLocation.y + playerNode.verticalFingerOffset
            )
        }
    }

    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard gameState == .playing, isDraggingPlayer, let touch = activeTouch, touches.contains(touch) else { return }
        let touchLocation = touch.location(in: self)
        playerNode.targetPosition = CGPoint(
            x: touchLocation.x + dragTouchOffset.x,
            y: touchLocation.y + dragTouchOffset.y
        )
    }

    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = activeTouch, touches.contains(touch) {
            isDraggingPlayer = false
            activeTouch = nil
        }
    }

    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = activeTouch, touches.contains(touch) {
            isDraggingPlayer = false
            activeTouch = nil
        }
    }
}
