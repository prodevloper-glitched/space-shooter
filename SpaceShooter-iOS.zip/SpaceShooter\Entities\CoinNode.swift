import SpriteKit

/// Collectible Coin entity in iOS SpriteKit.
/// Spawns at destroyed enemy position, drifts downward, homes in toward player when nearby,
/// and adds to the persistent coin balance upon pickup.
public final class CoinNode: SKNode {
    public let value: Int = 1
    public let radius: CGFloat = 16.0
    public let fallSpeed: CGFloat = 160.0
    public let magnetRadius: CGFloat = 220.0
    public let magnetSpeed: CGFloat = 650.0

    public init(value: Int = 1) {
        super.init()
        self.name = "coin"
        setupVisuals()
        setupPhysics()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupVisuals() {
        // Outer Gold Circle
        let outer = SKShapeNode(circleOfRadius: radius)
        outer.fillColor = UIColor(red: 1.0, green: 0.84, blue: 0.0, alpha: 1.0) // Gold
        outer.strokeColor = UIColor(red: 0.9, green: 0.65, blue: 0.0, alpha: 1.0)
        outer.lineWidth = 2.0
        addChild(outer)

        // Inner Embossed Ring
        let inner = SKShapeNode(circleOfRadius: radius * 0.65)
        inner.fillColor = .clear
        inner.strokeColor = UIColor(red: 0.85, green: 0.55, blue: 0.0, alpha: 1.0)
        inner.lineWidth = 2.5
        addChild(inner)

        // Subtle Shimmer Pulse Animation
        let scaleUp = SKAction.scale(to: 1.12, duration: 0.35)
        let scaleDown = SKAction.scale(to: 0.92, duration: 0.35)
        let pulse = SKAction.sequence([scaleUp, scaleDown])
        run(SKAction.repeatForever(pulse))
    }

    private func setupPhysics() {
        let body = SKPhysicsBody(circleOfRadius: radius)
        body.isDynamic = true
        body.categoryBitMask = PhysicsCategory.coin
        body.contactTestBitMask = PhysicsCategory.player
        body.collisionBitMask = PhysicsCategory.none
        body.affectedByGravity = false
        self.physicsBody = body
    }

    public func update(deltaTime: TimeInterval, playerPosition: CGPoint, bottomBoundary: CGFloat) {
        let dx = playerPosition.x - position.x
        let dy = playerPosition.y - position.y
        let distance = hypot(dx, dy)

        if distance <= magnetRadius && distance > 0.1 {
            let moveAmount = magnetSpeed * CGFloat(deltaTime)
            position.x += (dx / distance) * moveAmount
            position.y += (dy / distance) * moveAmount
        } else {
            position.y -= fallSpeed * CGFloat(deltaTime)
        }

        if position.y + radius < bottomBoundary - 50.0 {
            removeFromParent()
        }
    }
}
