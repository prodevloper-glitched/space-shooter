import SpriteKit

/// Heads-Up Display (HUD) node in iOS SpriteKit.
/// Anchors health bar, score, level, coins, and the [ ⏸ PAUSE ] button
/// safely inside the device's safe area insets.
public final class HUDNode: SKNode {

    private var hpBarBg: SKShapeNode!
    private var hpBarFill: SKShapeNode!
    private var hpLabel: SKLabelNode!

    private var levelLabel: SKLabelNode!
    private var scoreLabel: SKLabelNode!
    private var coinsLabel: SKLabelNode!

    public private(set) var pauseButton: SKShapeNode!
    private var pauseLabel: SKLabelNode!

    private let maxHpBarWidth: CGFloat = 200.0

    public override init() {
        super.init()
        self.name = "hud"
        self.zPosition = 100
        setupHUD()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupHUD() {
        // 1. Health Bar Components
        let barH: CGFloat = 20.0
        hpBarBg = SKShapeNode(rectOf: CGSize(width: maxHpBarWidth, height: barH), cornerRadius: 5.0)
        hpBarBg.fillColor = UIColor(red: 0.35, green: 0.08, blue: 0.08, alpha: 0.9)
        hpBarBg.strokeColor = .white
        hpBarBg.lineWidth = 2.0
        addChild(hpBarBg)

        hpBarFill = SKShapeNode(rectOf: CGSize(width: maxHpBarWidth, height: barH), cornerRadius: 5.0)
        hpBarFill.fillColor = UIColor(red: 0.0, green: 0.9, blue: 0.4, alpha: 1.0) // Vibrant Green
        hpBarFill.strokeColor = .clear
        addChild(hpBarFill)

        hpLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        hpLabel.fontSize = 13.0
        hpLabel.fontColor = .white
        hpLabel.verticalAlignmentMode = .center
        hpLabel.horizontalAlignmentMode = .center
        addChild(hpLabel)

        // 2. Level & Score Labels (Center)
        levelLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        levelLabel.fontSize = 16.0
        levelLabel.fontColor = UIColor(red: 0.0, green: 0.9, blue: 1.0, alpha: 1.0)
        levelLabel.horizontalAlignmentMode = .center
        addChild(levelLabel)

        scoreLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        scoreLabel.fontSize = 18.0
        scoreLabel.fontColor = .white
        scoreLabel.horizontalAlignmentMode = .center
        addChild(scoreLabel)

        // 3. Coin Counter & Pause Button (Top-Right)
        coinsLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        coinsLabel.fontSize = 18.0
        coinsLabel.fontColor = UIColor(red: 1.0, green: 0.84, blue: 0.0, alpha: 1.0)
        coinsLabel.horizontalAlignmentMode = .right
        addChild(coinsLabel)

        let btnSize = CGSize(width: 110.0, height: 38.0)
        pauseButton = SKShapeNode(rectOf: btnSize, cornerRadius: 8.0)
        pauseButton.fillColor = UIColor(red: 0.12, green: 0.16, blue: 0.28, alpha: 0.95)
        pauseButton.strokeColor = UIColor(red: 0.0, green: 0.75, blue: 1.0, alpha: 0.8)
        pauseButton.lineWidth = 1.5
        pauseButton.name = "btn_pause"
        addChild(pauseButton)

        pauseLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        pauseLabel.text = "⏸ PAUSE"
        pauseLabel.fontSize = 14.0
        pauseLabel.fontColor = .white
        pauseLabel.verticalAlignmentMode = .center
        pauseLabel.horizontalAlignmentMode = .center
        pauseLabel.name = "btn_pause"
        pauseButton.addChild(pauseLabel)
    }

    public func updateLayout(
        screenSize: CGSize,
        safeInsets: UIEdgeInsets
    ) {
        let topY = screenSize.height - max(safeInsets.top, 24.0) - 22.0
        let leftX = max(safeInsets.left, 44.0)
        let rightX = screenSize.width - max(safeInsets.right, 44.0)

        // Health Bar at Top-Left
        let barHalfW = maxHpBarWidth / 2.0
        hpBarBg.position = CGPoint(x: leftX + barHalfW, y: topY)
        hpBarFill.position = hpBarBg.position
        hpLabel.position = hpBarBg.position

        // Center Level & Score
        levelLabel.position = CGPoint(x: screenSize.width / 2.0, y: topY + 6.0)
        scoreLabel.position = CGPoint(x: screenSize.width / 2.0, y: topY - 14.0)

        // Top-Right Pause Button & Coins
        pauseButton.position = CGPoint(x: rightX - 55.0, y: topY)
        coinsLabel.position = CGPoint(x: rightX - 125.0, y: topY - 6.0)
    }

    public func update(
        currentHealth: Int,
        maxHealth: Int,
        score: Int,
        level: Int,
        coins: Int
    ) {
        let ratio = max(0.0, min(1.0, CGFloat(currentHealth) / CGFloat(maxHealth)))
        hpBarFill.xScale = ratio
        hpLabel.text = "HP: \(currentHealth) / \(maxHealth)"

        levelLabel.text = "LEVEL \(level)"
        scoreLabel.text = "SCORE: \(score)"
        coinsLabel.text = "🪙 \(coins)"
    }
}
