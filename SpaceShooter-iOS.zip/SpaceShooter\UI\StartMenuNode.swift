import SpriteKit

/// Start Screen overlay for iOS 2D Space Shooter.
/// Displays game title, interceptor showcase, and a large "START GAME" button.
public final class StartMenuNode: SKNode {

    public private(set) var startButton: SKShapeNode!

    public init(screenSize: CGSize) {
        super.init()
        self.name = "start_menu"
        self.zPosition = 200
        setupView(screenSize: screenSize)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView(screenSize: CGSize) {
        let centerX = screenSize.width / 2.0
        let centerY = screenSize.height / 2.0

        // Translucent Backdrop
        let backdrop = SKSpriteNode(color: UIColor(white: 0.0, alpha: 0.65), size: screenSize)
        backdrop.position = CGPoint(x: centerX, y: centerY)
        addChild(backdrop)

        // 1. Title Banner
        let titleLabel = SKLabelNode(fontNamed: "HelveticaNeue-BlackCondensed")
        titleLabel.text = "SPACE SHOOTER"
        titleLabel.fontSize = min(screenSize.height * 0.12, 54.0)
        titleLabel.fontColor = UIColor(red: 0.0, green: 0.85, blue: 1.0, alpha: 1.0)
        titleLabel.position = CGPoint(x: centerX, y: centerY + screenSize.height * 0.24)
        addChild(titleLabel)

        let subtitleLabel = SKLabelNode(fontNamed: "HelveticaNeue-Medium")
        subtitleLabel.text = "GALAXY INTERCEPTOR • iOS EDITION"
        subtitleLabel.fontSize = min(screenSize.height * 0.045, 18.0)
        subtitleLabel.fontColor = UIColor(red: 0.7, green: 0.85, blue: 1.0, alpha: 0.9)
        subtitleLabel.position = CGPoint(x: centerX, y: titleLabel.position.y - 30.0)
        addChild(subtitleLabel)

        // 2. Spaceship Showcase Preview
        let previewShip = PlayerNode()
        previewShip.position = CGPoint(x: centerX, y: centerY + 10.0)
        previewShip.setScale(1.15)
        previewShip.autoFire = false
        previewShip.physicsBody = nil
        addChild(previewShip)

        // Floating hover animation for showcase
        let hoverUp = SKAction.moveBy(x: 0, y: 12.0, duration: 1.2)
        hoverUp.timingMode = .easeInEaseOut
        let hoverDown = hoverUp.reversed()
        previewShip.run(SKAction.repeatForever(SKAction.sequence([hoverUp, hoverDown])))

        // 3. START GAME Button
        let btnSize = CGSize(width: min(screenSize.width * 0.40, 260.0), height: 56.0)
        startButton = SKShapeNode(rectOf: btnSize, cornerRadius: 14.0)
        startButton.fillColor = UIColor(red: 0.0, green: 0.8, blue: 0.35, alpha: 1.0) // Vibrant Emerald Green
        startButton.strokeColor = UIColor(red: 0.3, green: 1.0, blue: 0.6, alpha: 1.0)
        startButton.lineWidth = 3.0
        startButton.position = CGPoint(x: centerX, y: centerY - screenSize.height * 0.22)
        startButton.name = "btn_start_game"
        addChild(startButton)

        let startLabel = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        startLabel.text = "START GAME"
        startLabel.fontSize = 22.0
        startLabel.fontColor = .white
        startLabel.verticalAlignmentMode = .center
        startLabel.horizontalAlignmentMode = .center
        startLabel.name = "btn_start_game"
        startButton.addChild(startLabel)

        // Button pulsing highlight
        let pulseUp = SKAction.scale(to: 1.05, duration: 0.6)
        let pulseDown = SKAction.scale(to: 0.98, duration: 0.6)
        startButton.run(SKAction.repeatForever(SKAction.sequence([pulseUp, pulseDown])))

        // Instruction Label
        let instructionLabel = SKLabelNode(fontNamed: "HelveticaNeue-Light")
        instructionLabel.text = "Drag ship with finger • Auto-firing enabled"
        instructionLabel.fontSize = 14.0
        instructionLabel.fontColor = UIColor(white: 0.8, alpha: 0.8)
        instructionLabel.position = CGPoint(x: centerX, y: startButton.position.y - 45.0)
        addChild(instructionLabel)
    }
}
