import Foundation
import AVFoundation

/// High-performance audio manager for iOS 2D Space Shooter.
/// Utilizes AVAudioPlayer pools preloaded with synthesized PCM WAV audio buffers.
/// 100% self-contained: works out of the box with zero external media files.
public final class AudioManager {
    public static let shared = AudioManager()

    public var isMuted: Bool = false

    private let sampleRate: Double = 44100.0

    private var laserPlayers: [AVAudioPlayer] = []
    private var explosionPlayers: [AVAudioPlayer] = []
    private var coinPlayers: [AVAudioPlayer] = []
    private var clickPlayers: [AVAudioPlayer] = []

    private var laserIndex = 0
    private var explosionIndex = 0
    private var coinIndex = 0
    private var clickIndex = 0

    private let poolSize = 6

    private init() {
        configureAudioSession()
        prepareAudioPools()
    }

    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .gameChat, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("[AudioManager] Failed to configure AVAudioSession: \(error)")
        }
    }

    private func prepareAudioPools() {
        if let laserData = generateLaserWavData() {
            laserPlayers = createPlayerPool(from: laserData, count: poolSize, volume: 0.65)
        }
        if let explosionData = generateExplosionWavData() {
            explosionPlayers = createPlayerPool(from: explosionData, count: poolSize, volume: 0.85)
        }
        if let coinData = generateCoinWavData() {
            coinPlayers = createPlayerPool(from: coinData, count: poolSize, volume: 0.90)
        }
        if let clickData = generateClickWavData() {
            clickPlayers = createPlayerPool(from: clickData, count: 4, volume: 0.70)
        }
    }

    private func createPlayerPool(from data: Data, count: Int, volume: Float) -> [AVAudioPlayer] {
        var pool: [AVAudioPlayer] = []
        for _ in 0..<count {
            if let player = try? AVAudioPlayer(data: data) {
                player.volume = volume
                player.prepareToPlay()
                pool.append(player)
            }
        }
        return pool
    }

    public func playLaser() {
        guard !isMuted, !laserPlayers.isEmpty else { return }
        let player = laserPlayers[laserIndex]
        player.currentTime = 0
        player.play()
        laserIndex = (laserIndex + 1) % laserPlayers.count
    }

    public func playExplosion() {
        guard !isMuted, !explosionPlayers.isEmpty else { return }
        let player = explosionPlayers[explosionIndex]
        player.currentTime = 0
        player.play()
        explosionIndex = (explosionIndex + 1) % explosionPlayers.count
    }

    public func playCoin() {
        guard !isMuted, !coinPlayers.isEmpty else { return }
        let player = coinPlayers[coinIndex]
        player.currentTime = 0
        player.play()
        coinIndex = (coinIndex + 1) % coinPlayers.count
    }

    public func playClick() {
        guard !isMuted, !clickPlayers.isEmpty else { return }
        let player = clickPlayers[clickIndex]
        player.currentTime = 0
        player.play()
        clickIndex = (clickIndex + 1) % clickPlayers.count
    }

    // MARK: - Procedural WAV Synthesis

    private func generateLaserWavData() -> Data? {
        let duration = 0.12
        let numSamples = Int(sampleRate * duration)
        var samples = [Int16](repeating: 0, count: numSamples)

        for i in 0..<numSamples {
            let t = Double(i) / Double(numSamples)
            // Downward pitch sweep from 1050 Hz to 220 Hz
            let freq = 1050.0 - 830.0 * t
            let envelope = max(0.0, 1.0 - t * 0.9)
            let phase = 2.0 * Double.pi * freq * (Double(i) / sampleRate)
            let value = sin(phase) * envelope * 0.75
            samples[i] = Int16(clamping: Int(value * 32767.0))
        }
        return createWavData(samples: samples)
    }

    private func generateExplosionWavData() -> Data? {
        let duration = 0.32
        let numSamples = Int(sampleRate * duration)
        var samples = [Int16](repeating: 0, count: numSamples)

        for i in 0..<numSamples {
            let t = Double(i) / Double(numSamples)
            let noise = Double.random(in: -1.0...1.0)
            let rumble = sin(2.0 * Double.pi * 75.0 * (Double(i) / sampleRate))
            let decay = exp(-t * 6.5)
            let value = (noise * 0.7 + rumble * 0.3) * decay * 0.9
            samples[i] = Int16(clamping: Int(value * 32767.0))
        }
        return createWavData(samples: samples)
    }

    private func generateCoinWavData() -> Data? {
        let duration = 0.18
        let numSamples = Int(sampleRate * duration)
        var samples = [Int16](repeating: 0, count: numSamples)
        let halfSamples = numSamples / 2

        for i in 0..<numSamples {
            let t = Double(i) / sampleRate
            let freq = i < halfSamples ? 987.77 : 1318.51 // B5 -> E6 chime
            let decay = 1.0 - (Double(i) / Double(numSamples))
            let value = sin(2.0 * Double.pi * freq * t) * decay * 0.85
            samples[i] = Int16(clamping: Int(value * 32767.0))
        }
        return createWavData(samples: samples)
    }

    private func generateClickWavData() -> Data? {
        let duration = 0.03
        let numSamples = Int(sampleRate * duration)
        var samples = [Int16](repeating: 0, count: numSamples)

        for i in 0..<numSamples {
            let t = Double(i) / sampleRate
            let decay = 1.0 - (Double(i) / Double(numSamples))
            let value = sin(2.0 * Double.pi * 950.0 * t) * decay * 0.5
            samples[i] = Int16(clamping: Int(value * 32767.0))
        }
        return createWavData(samples: samples)
    }

    private func createWavData(samples: [Int16]) -> Data {
        let numChannels: UInt16 = 1
        let bitsPerSample: UInt16 = 16
        let byteRate: UInt32 = UInt32(sampleRate) * UInt32(numChannels) * UInt32(bitsPerSample / 8)
        let blockAlign: UInt16 = numChannels * (bitsPerSample / 8)
        let subchunk2Size: UInt32 = UInt32(samples.count * 2)
        let chunkSize: UInt32 = 36 + subchunk2Size

        var data = Data()

        // RIFF header
        data.append(contentsOf: [0x52, 0x49, 0x46, 0x46]) // "RIFF"
        data.append(withUnsafeBytes(of: chunkSize.littleEndian) { Data($0) })
        data.append(contentsOf: [0x57, 0x41, 0x56, 0x45]) // "WAVE"

        // "fmt " chunk
        data.append(contentsOf: [0x66, 0x6D, 0x74, 0x20]) // "fmt "
        let subchunk1Size: UInt32 = 16
        data.append(withUnsafeBytes(of: subchunk1Size.littleEndian) { Data($0) })
        let audioFormat: UInt16 = 1 // PCM
        data.append(withUnsafeBytes(of: audioFormat.littleEndian) { Data($0) })
        data.append(withUnsafeBytes(of: numChannels.littleEndian) { Data($0) })
        let sampleRateU32 = UInt32(sampleRate)
        data.append(withUnsafeBytes(of: sampleRateU32.littleEndian) { Data($0) })
        data.append(withUnsafeBytes(of: byteRate.littleEndian) { Data($0) })
        data.append(withUnsafeBytes(of: blockAlign.littleEndian) { Data($0) })
        data.append(withUnsafeBytes(of: bitsPerSample.littleEndian) { Data($0) })

        // "data" chunk
        data.append(contentsOf: [0x64, 0x61, 0x74, 0x61]) // "data"
        data.append(withUnsafeBytes(of: subchunk2Size.littleEndian) { Data($0) })

        // Samples
        samples.withUnsafeBufferPointer { buffer in
            data.append(buffer)
        }

        return data
    }
}
