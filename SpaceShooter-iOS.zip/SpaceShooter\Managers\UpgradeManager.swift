import Foundation

/// Singleton UpgradeManager for native iOS 2D Space Shooter.
/// Tracks and scales costs for 1) Bullet Damage, 2) Fire Rate, and 3) Max Health.
public final class UpgradeManager {
    public static let shared = UpgradeManager()

    private let keyDamage = "shooter_upgrade_damage_level"
    private let keyFireRate = "shooter_upgrade_firerate_level"
    private let keyHealth = "shooter_upgrade_health_level"

    public static let maxLevel: Int = 10

    public private(set) var damageLevel: Int = 0
    public private(set) var fireRateLevel: Int = 0
    public private(set) var healthLevel: Int = 0

    private let damageBaseCost: Double = 50.0
    private let fireRateBaseCost: Double = 60.0
    private let healthBaseCost: Double = 40.0
    private let costMultiplier: Double = 1.6

    private init() {
        damageLevel = UserDefaults.standard.integer(forKey: keyDamage)
        fireRateLevel = UserDefaults.standard.integer(forKey: keyFireRate)
        healthLevel = UserDefaults.standard.integer(forKey: keyHealth)
    }

    public var currentDamage: Int {
        return 1 + damageLevel
    }

    public var currentFireIntervalSec: TimeInterval {
        let intervalMs = max(60.0, 180.0 - Double(fireRateLevel * 12))
        return intervalMs / 1000.0
    }

    public var currentMaxHealth: Int {
        return 3 + healthLevel
    }

    public func getDamageCost() -> Int {
        guard damageLevel < UpgradeManager.maxLevel else { return -1 }
        return Int((damageBaseCost * pow(costMultiplier, Double(damageLevel))).rounded())
    }

    public func getFireRateCost() -> Int {
        guard fireRateLevel < UpgradeManager.maxLevel else { return -1 }
        return Int((fireRateBaseCost * pow(costMultiplier, Double(fireRateLevel))).rounded())
    }

    public func getHealthCost() -> Int {
        guard healthLevel < UpgradeManager.maxLevel else { return -1 }
        return Int((healthBaseCost * pow(costMultiplier, Double(healthLevel))).rounded())
    }

    @discardableResult
    public func tryBuyDamage() -> Bool {
        let cost = getDamageCost()
        guard cost > 0 else { return false }
        if GameManager.shared.spendCoins(cost) {
            damageLevel += 1
            UserDefaults.standard.set(damageLevel, forKey: keyDamage)
            return true
        }
        return false
    }

    @discardableResult
    public func tryBuyFireRate() -> Bool {
        let cost = getFireRateCost()
        guard cost > 0 else { return false }
        if GameManager.shared.spendCoins(cost) {
            fireRateLevel += 1
            UserDefaults.standard.set(fireRateLevel, forKey: keyFireRate)
            return true
        }
        return false
    }

    @discardableResult
    public func tryBuyHealth() -> Bool {
        let cost = getHealthCost()
        guard cost > 0 else { return false }
        if GameManager.shared.spendCoins(cost) {
            healthLevel += 1
            UserDefaults.standard.set(healthLevel, forKey: keyHealth)
            return true
        }
        return false
    }
}
