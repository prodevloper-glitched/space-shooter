import SpriteKit

/// Enemy Aircraft entity in iOS SpriteKit.
/// Distinctively colored RED with aggressive swept wings, menacing gold visor,
/// multi-hit health points, damage flash feedback, and an overhead health bar.
public final class EnemyNode: SKNode {
    public let shipWidth: CGFloat = 85.0
    public let shipHeight: CGFloat = 95.0
    public var speedValue: CGFloat = 260.0
    public let scoreValue: Int = 100

    public let maxHealth: Int
    public var health: Int
    public var isDestroyed: Bool = false

    private var hullNode: SKShapeNode!
    private var visorNode: SKShapeNode!
    private var hpBarContainer: SKNode?
    private var hpBarFillNode: SKShapeNode?

    private let normalHullColor = UIColor(red: 0.90, green: 0.08, blue: 0.18, alpha: 1.0) // Vivid Crimson Red
    private let strokeColor = UIColor(red: 0.55, green: 0.0, blue: 0.08, alpha: 1.0) // Deep Dark Red

    public init(maxHealth: Int = 3, speed: CGFloat = 260.0) {
        self.maxHealth = maxHealth
        self.health = maxHealth
        self.speedValue = speed
        super.init()
        self.name = "enemy"
        setupVisuals()
        setupPhysics()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupVisuals() {
        let halfW = shipWidth / 2.0
        let halfH = shipHeight / 2.0

        // 1. Inverted Aggressive RED Fighter Hull (pointed DOWN towards player)
        let enemyPath = CGMutablePath()
        enemyPath.move(to: CGPoint(x: 0, y: -halfH)) // Nose pointed down
        enemyPath.addLine(to: CGPoint(x: -halfW * 0.3, y: -halfH * 0.3))
        enemyPath.addLine(to: CGPoint(x: -halfW, y: halfH * 0.5)) // Left wing
        enemyPath.addLine(to: CGPoint(x: -halfW * 0.7, y: halfH * 0.8)) // Left wingtip fin
        enemyPath.addLine(to: CGPoint(x: -halfW * 0.25, y: halfH * 0.4))
        enemyPath.addLine(to: CGPoint(x: 0, y: halfH * 0.7)) // Rear notch
        enemyPath.addLine(to: CGPoint(x: halfW * 0.25, y: halfH * 0.4))
        enemyPath.addLine(to: CGPoint(x: halfW * 0.7, y: halfH * 0.8)) // Right wingtip fin
        enemyPath.addLine(to: CGPoint(x: halfW, y: halfH * 0.5)) // Right wing
        enemyPath.addLine(to: CGPoint(x: halfW * 0.3, y: -halfH * 0.3))
        enemyPath.closeSubpath()

        hullNode = SKShapeNode(path: enemyPath)
        hullNode.fillColor = normalHullColor
        hullNode.strokeColor = strokeColor
        hullNode.lineWidth = 3.0
        addChild(hullNode)

        // 2. Menacing Gold/Yellow Visor
        let visorRect = CGRect(x: -halfW * 0.2, y: -halfH * 0.35, width: halfW * 0.4, height: halfH * 0.3)
        visorNode = SKShapeNode(ellipseIn: visorRect)
        visorNode.fillColor = UIColor(red: 1.0, green: 0.84, blue: 0.0, alpha: 1.0)
        visorNode.strokeColor = UIColor(red: 0.8, green: 0.5, blue: 0.0, alpha: 1.0)
        visorNode.lineWidth = 1.0
        addChild(visorNode)
    }

    private func setupPhysics() {
        let bodySize = CGSize(width: shipWidth * 0.75, height: shipHeight * 0.75)
        let body = SKPhysicsBody(rectangleOf: bodySize)
        body.isDynamic = true
        body.categoryBitMask = PhysicsCategory.enemy
        body.contactTestBitMask = PhysicsCategory.bullet | PhysicsCategory.player
        body.collisionBitMask = PhysicsCategory.none
        body.affectedByGravity = false
        self.physicsBody = body
    }

    @discardableResult
    public func takeDamage(_ damage: Int) -> Bool {
        guard !isDestroyed else { return true }
        health -= damage

        // Hit flash feedback (flash white)
        hullNode.fillColor = .white
        let restoreColor = SKAction.run { [weak self] in
            guard let self = self else { return }
            self.hullNode.fillColor = self.normalHullColor
        }
        run(SKAction.sequence([SKAction.wait(forDuration: 0.08), restoreColor]))

        updateHealthBar()

        if health <= 0 {
            isDestroyed = true
            return true
        }
        return false
    }

    private func updateHealthBar() {
        if hpBarContainer == nil {
            let container = SKNode()
            container.position = CGPoint(x: 0, y: shipHeight * 0.55 + 10.0)

            let barW = shipWidth * 0.85
            let barH: CGFloat = 7.0

            let bg = SKShapeNode(rectOf: CGSize(width: barW, height: barH), cornerRadius: 2.0)
            bg.fillColor = UIColor(red: 0.25, green: 0.05, blue: 0.05, alpha: 0.9)
            bg.strokeColor = .clear
            container.addChild(bg)

            let fill = SKShapeNode(rectOf: CGSize(width: barW, height: barH), cornerRadius: 2.0)
            fill.fillColor = UIColor(red: 0.2, green: 0.9, blue: 0.35, alpha: 1.0)
            fill.strokeColor = .clear
            container.addChild(fill)

            hpBarFillNode = fill
            hpBarContainer = container
            addChild(container)
        }

        let barW = shipWidth * 0.85
        let ratio = max(0.0, CGFloat(health) / CGFloat(maxHealth))
        hpBarFillNode?.xScale = ratio
    }

    public func update(deltaTime: TimeInterval, bottomBoundary: CGFloat) {
        position.y -= speedValue * CGFloat(deltaTime)
        if position.y + shipHeight < bottomBoundary - 40.0 {
            isDestroyed = true
            removeFromParent()
        }
    }
}
