import SpriteKit

/// High-performance multi-layered parallax space background for iOS SpriteKit.
/// Continuous downward scrolling creates a smooth flying illusion:
/// - Layer 1 (Distant): 80 micro-stars drifting at 35 pt/s
/// - Layer 2 (Mid-field): 40 medium stars with subtle cyan/amber tints drifting at 90 pt/s
/// - Layer 3 (Foreground): 20 bright warp stars drifting at 220 pt/s
/// - Cosmic Nebulae: 3 soft glowing dust clouds (violet, cyan, magenta)
public final class SpaceBackgroundNode: SKNode {

    private struct Star {
        let node: SKShapeNode
        var speed: CGFloat
    }

    private struct Nebula {
        let node: SKShapeNode
        var speed: CGFloat
        let radius: CGFloat
    }

    private var stars: [Star] = []
    private var nebulae: [Nebula] = []
    private var screenSize: CGSize = .zero
    private var bgFill: SKSpriteNode?

    public init(size: CGSize) {
        super.init()
        self.screenSize = size
        self.zPosition = -100
        setupBackground()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public func resize(to newSize: CGSize) {
        self.screenSize = newSize
        removeAllChildren()
        stars.removeAll()
        nebulae.removeAll()
        setupBackground()
    }

    private func setupBackground() {
        guard screenSize.width > 0, screenSize.height > 0 else { return }

        // 1. Deep Space Midnight Navy Base
        let bg = SKSpriteNode(color: UIColor(red: 0.03, green: 0.05, blue: 0.09, alpha: 1.0), size: screenSize)
        bg.position = CGPoint(x: screenSize.width / 2.0, y: screenSize.height / 2.0)
        bg.zPosition = -10
        addChild(bg)
        bgFill = bg

        let baseDim = min(screenSize.width, screenSize.height)

        // 2. Cosmic Nebulae (3 soft dust clouds)
        let nebulaColors: [(UIColor, CGFloat, CGFloat, CGFloat, CGFloat)] = [
            (UIColor(red: 0.43, green: 0.16, blue: 0.70, alpha: 0.22), 0.25, 0.35, baseDim * 0.55, 22.0), // Deep Violet
            (UIColor(red: 0.08, green: 0.40, blue: 0.82, alpha: 0.20), 0.75, 0.65, baseDim * 0.60, 28.0), // Cosmic Cyan
            (UIColor(red: 0.67, green: 0.12, blue: 0.43, alpha: 0.18), 0.50, 0.95, baseDim * 0.50, 18.0)  // Magenta Dust
        ]

        for item in nebulaColors {
            let nebNode = SKShapeNode(circleOfRadius: item.3)
            nebNode.fillColor = item.0
            nebNode.strokeColor = .clear
            nebNode.position = CGPoint(x: screenSize.width * item.1, y: screenSize.height * item.2)
            nebNode.zPosition = -5
            addChild(nebNode)
            nebulae.append(Nebula(node: nebNode, speed: item.4, radius: item.3))
        }

        // 3. Layer 1: Distant micro-stars (80 count)
        for _ in 0..<80 {
            let radius = CGFloat.random(in: 1.0...2.0)
            let starNode = SKShapeNode(circleOfRadius: radius)
            let colorOption = Int.random(in: 0...3)
            let color: UIColor = {
                switch colorOption {
                case 0: return UIColor(red: 0.78, green: 0.88, blue: 1.0, alpha: 0.65)
                case 1: return UIColor(red: 1.0, green: 0.94, blue: 0.86, alpha: 0.70)
                default: return UIColor(white: 1.0, alpha: 0.75)
                }
            }()
            starNode.fillColor = color
            starNode.strokeColor = .clear
            starNode.position = CGPoint(
                x: CGFloat.random(in: 0...screenSize.width),
                y: CGFloat.random(in: 0...screenSize.height)
            )
            starNode.zPosition = -3
            addChild(starNode)
            stars.append(Star(node: starNode, speed: CGFloat.random(in: 30...50)))
        }

        // 4. Layer 2: Mid-field stars (40 count)
        for _ in 0..<40 {
            let radius = CGFloat.random(in: 2.0...3.2)
            let starNode = SKShapeNode(circleOfRadius: radius)
            let colorOption = Int.random(in: 0...2)
            let color: UIColor = {
                switch colorOption {
                case 0: return UIColor(red: 0.51, green: 0.82, blue: 1.0, alpha: 0.9) // Electric Cyan
                case 1: return UIColor(red: 1.0, green: 0.82, blue: 0.63, alpha: 0.9) // Solar Amber
                default: return UIColor(white: 1.0, alpha: 0.9)
                }
            }()
            starNode.fillColor = color
            starNode.strokeColor = .clear
            starNode.position = CGPoint(
                x: CGFloat.random(in: 0...screenSize.width),
                y: CGFloat.random(in: 0...screenSize.height)
            )
            starNode.zPosition = -2
            addChild(starNode)
            stars.append(Star(node: starNode, speed: CGFloat.random(in: 80...120)))
        }

        // 5. Layer 3: Foreground warp stars (20 count)
        for _ in 0..<20 {
            let radius = CGFloat.random(in: 3.2...4.8)
            let starNode = SKShapeNode(circleOfRadius: radius)
            starNode.fillColor = .white
            starNode.strokeColor = .clear
            starNode.position = CGPoint(
                x: CGFloat.random(in: 0...screenSize.width),
                y: CGFloat.random(in: 0...screenSize.height)
            )
            starNode.zPosition = -1
            addChild(starNode)
            stars.append(Star(node: starNode, speed: CGFloat.random(in: 200...260)))
        }
    }

    public func update(deltaTime: TimeInterval) {
        let dt = CGFloat(min(max(deltaTime, 0.001), 0.1))

        // Scroll stars downward
        for star in stars {
            star.node.position.y -= star.speed * dt
            if star.node.position.y < 0 {
                star.node.position.y = screenSize.height
                star.node.position.x = CGFloat.random(in: 0...screenSize.width)
            }
        }

        // Scroll nebulae downward
        for nebula in nebulae {
            nebula.node.position.y -= nebula.speed * dt
            if nebula.node.position.y + nebula.radius < 0 {
                nebula.node.position.y = screenSize.height + nebula.radius
                nebula.node.position.x = CGFloat.random(in: 0...screenSize.width)
            }
        }
    }
}
