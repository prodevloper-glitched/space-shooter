import Foundation

/// Collision and contact bitmasks for SpriteKit physics detection.
public struct PhysicsCategory {
    public static let none: UInt32    = 0
    public static let player: UInt32  = 1 << 0
    public static let enemy: UInt32   = 1 << 1
    public static let bullet: UInt32  = 1 << 2
    public static let coin: UInt32    = 1 << 3
}
