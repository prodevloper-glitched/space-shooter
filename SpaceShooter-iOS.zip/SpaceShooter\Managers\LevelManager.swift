import Foundation

/// Singleton LevelManager for native iOS 2D Space Shooter.
/// Tracks level progression, kill quotas, difficulty scaling, and victory rewards.
public final class LevelManager {
    public static let shared = LevelManager()

    public private(set) var currentLevel: Int = 1
    public private(set) var currentKills: Int = 0
    public private(set) var targetKills: Int = 15
    public private(set) var isLevelCleared: Bool = false

    private let baseKills: Int = 15
    private let killsPerLevel: Int = 5
    private let baseBonusCoins: Int = 50
    private let bonusPerLevel: Int = 20

    private init() {
        startLevel(1)
    }

    public func startLevel(_ level: Int) {
        currentLevel = level
        currentKills = 0
        targetKills = baseKills + (currentLevel - 1) * killsPerLevel
        isLevelCleared = false
    }

    @discardableResult
    public func registerEnemyKill(onCleared: ((_ completedLevel: Int, _ bonusCoins: Int) -> Void)? = nil) -> Bool {
        guard !isLevelCleared else { return false }

        currentKills += 1
        if currentKills >= targetKills {
            isLevelCleared = true
            let bonus = baseBonusCoins + (currentLevel - 1) * bonusPerLevel
            GameManager.shared.addCoins(bonus)
            onCleared?(currentLevel, bonus)
            return true
        }
        return false
    }

    public func proceedToNextLevel() {
        startLevel(currentLevel + 1)
    }

    public func getSpeedMultiplier() -> Float {
        return 1.0 + Float(currentLevel - 1) * 0.12
    }

    public func getSpawnIntervalReduction() -> Float {
        return Float(currentLevel - 1) * 0.06
    }
}
