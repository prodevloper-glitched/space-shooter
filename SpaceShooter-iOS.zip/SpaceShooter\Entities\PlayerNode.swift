import SpriteKit

/// Player Spaceship entity in iOS SpriteKit.
/// Distinctively colored BLUE with electric cyan accents, glass cockpit canopy,
/// animated flickering thruster flames, multi-point health system, and safe area clamping.
public final class PlayerNode: SKNode {
    public let shipWidth: CGFloat = 100.0
    public let shipHeight: CGFloat = 110.0

    // Smooth drag movement
    public var targetPosition: CGPoint = .zero
    public var smoothFactor: CGFloat = 0.28
    public var verticalFingerOffset: CGFloat = 85.0

    // Weapon & Upgrades
    public var autoFire: Bool = true
    public var fireIntervalSec: TimeInterval = 0.18
    public var bulletDamage: Int = 1
    private var lastFireTime: TimeInterval = 0

    // Health System
    public var maxHealth: Int = 5
    public var currentHealth: Int = 5
    public var isAlive: Bool = true

    // Invulnerability Flashing Feedback
    private var isInvulnerable: Bool = false
    private let invulnerableDuration: TimeInterval = 1.2

    // Nodes
    private var hullNode: SKShapeNode!
    private var wingOutlineNode: SKShapeNode!
    private var canopyNode: SKShapeNode!
    private var outerFlameNode: SKShapeNode!
    private var innerFlameNode: SKShapeNode!

    public override init() {
        super.init()
        self.name = "player"
        setupVisuals()
        setupPhysics()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupVisuals() {
        let halfW = shipWidth / 2.0
        let halfH = shipHeight / 2.0

        // 1. Rear Thruster Flame (Amber & Yellow core)
        let outerFlamePath = CGMutablePath()
        outerFlamePath.move(to: CGPoint(x: -halfW * 0.25, y: -halfH * 0.7))
        outerFlamePath.addLine(to: CGPoint(x: 0, y: -halfH * 1.35))
        outerFlamePath.addLine(to: CGPoint(x: halfW * 0.25, y: -halfH * 0.7))
        outerFlamePath.closeSubpath()

        outerFlameNode = SKShapeNode(path: outerFlamePath)
        outerFlameNode.fillColor = UIColor(red: 1.0, green: 0.55, blue: 0.0, alpha: 0.95)
        outerFlameNode.strokeColor = .clear
        addChild(outerFlameNode)

        let innerFlamePath = CGMutablePath()
        innerFlamePath.move(to: CGPoint(x: -halfW * 0.12, y: -halfH * 0.7))
        innerFlamePath.addLine(to: CGPoint(x: 0, y: -halfH * 1.15))
        innerFlamePath.addLine(to: CGPoint(x: halfW * 0.12, y: -halfH * 0.7))
        innerFlamePath.closeSubpath()

        innerFlameNode = SKShapeNode(path: innerFlamePath)
        innerFlameNode.fillColor = UIColor(red: 1.0, green: 0.92, blue: 0.35, alpha: 1.0)
        innerFlameNode.strokeColor = .clear
        addChild(innerFlameNode)

        // Thruster flicker animation
        let stretch = SKAction.scaleY(to: 1.35, duration: 0.08)
        let compress = SKAction.scaleY(to: 0.85, duration: 0.08)
        let flamePulse = SKAction.sequence([stretch, compress])
        outerFlameNode.run(SKAction.repeatForever(flamePulse))
        innerFlameNode.run(SKAction.repeatForever(flamePulse))

        // 2. Distinctive BLUE Fuselage & Wings (Futuristic Interceptor)
        let shipPath = CGMutablePath()
        shipPath.move(to: CGPoint(x: 0, y: halfH)) // Sharp Nose
        shipPath.addLine(to: CGPoint(x: -halfW * 0.25, y: halfH * 0.2))
        shipPath.addLine(to: CGPoint(x: -halfW, y: -halfH * 0.6)) // Left wingtip
        shipPath.addLine(to: CGPoint(x: -halfW * 0.5, y: -halfH * 0.5)) // Wing notch
        shipPath.addLine(to: CGPoint(x: -halfW * 0.35, y: -halfH * 0.75)) // Left nozzle
        shipPath.addLine(to: CGPoint(x: 0, y: -halfH * 0.45)) // Rear center notch
        shipPath.addLine(to: CGPoint(x: halfW * 0.35, y: -halfH * 0.75)) // Right nozzle
        shipPath.addLine(to: CGPoint(x: halfW * 0.5, y: -halfH * 0.5))
        shipPath.addLine(to: CGPoint(x: halfW, y: -halfH * 0.6)) // Right wingtip
        shipPath.addLine(to: CGPoint(x: halfW * 0.25, y: halfH * 0.2))
        shipPath.closeSubpath()

        hullNode = SKShapeNode(path: shipPath)
        hullNode.fillColor = UIColor(red: 0.0, green: 0.4, blue: 1.0, alpha: 1.0) // Vibrant Royal Blue
        hullNode.strokeColor = UIColor(red: 0.0, green: 0.9, blue: 1.0, alpha: 1.0) // Electric Cyan Accent
        hullNode.lineWidth = 3.5
        addChild(hullNode)

        // 3. Glowing Glass Cockpit Canopy
        let canopyRect = CGRect(x: -halfW * 0.18, y: -halfH * 0.1, width: halfW * 0.36, height: halfH * 0.55)
        canopyNode = SKShapeNode(ellipseIn: canopyRect)
        canopyNode.fillColor = UIColor(red: 0.7, green: 0.96, blue: 1.0, alpha: 0.95)
        canopyNode.strokeColor = UIColor(red: 0.3, green: 0.8, blue: 1.0, alpha: 1.0)
        canopyNode.lineWidth = 1.5
        addChild(canopyNode)
    }

    private func setupPhysics() {
        let bodySize = CGSize(width: shipWidth * 0.75, height: shipHeight * 0.75)
        let body = SKPhysicsBody(rectangleOf: bodySize)
        body.isDynamic = true
        body.categoryBitMask = PhysicsCategory.player
        body.contactTestBitMask = PhysicsCategory.enemy | PhysicsCategory.coin
        body.collisionBitMask = PhysicsCategory.none
        body.affectedByGravity = false
        self.physicsBody = body
    }

    public func reset(to startPos: CGPoint) {
        position = startPos
        targetPosition = startPos
        currentHealth = maxHealth
        isAlive = true
        isInvulnerable = false
        alpha = 1.0
        removeAllActions()
    }

    public func applyUpgrades(damage: Int, fireInterval: TimeInterval, maxHp: Int) {
        bulletDamage = damage
        fireIntervalSec = fireInterval
        let hpDiff = maxHp - maxHealth
        maxHealth = maxHp
        if hpDiff > 0 {
            currentHealth += hpDiff
        }
    }

    @discardableResult
    public func takeDamage(_ amount: Int) -> Bool {
        guard isAlive, !isInvulnerable else { return false }

        currentHealth = max(0, currentHealth - amount)
        isInvulnerable = true

        if currentHealth <= 0 {
            isAlive = false
            return true
        }

        // Damage invulnerability blink animation
        let blinkOut = SKAction.fadeAlpha(to: 0.25, duration: 0.08)
        let blinkIn = SKAction.fadeAlpha(to: 1.0, duration: 0.08)
        let blinkSeq = SKAction.sequence([blinkOut, blinkIn])
        let blinkCount = Int(invulnerableDuration / 0.16)
        let blinkRepeated = SKAction.repeat(blinkSeq, count: blinkCount)
        let endInvulnerability = SKAction.run { [weak self] in
            self?.isInvulnerable = false
            self?.alpha = 1.0
        }
        run(SKAction.sequence([blinkRepeated, endInvulnerability]))
        return true
    }

    public func heal(_ amount: Int) {
        currentHealth = min(maxHealth, currentHealth + amount)
    }

    public func update(
        currentTime: TimeInterval,
        safeMinX: CGFloat,
        safeMaxX: CGFloat,
        safeMinY: CGFloat,
        safeMaxY: CGFloat,
        onShoot: (CGPoint, Int) -> Void
    ) {
        guard isAlive else { return }

        // Smooth position interpolation
        position.x += (targetPosition.x - position.x) * smoothFactor
        position.y += (targetPosition.y - position.y) * smoothFactor

        // Clamp inside safe bounds
        let halfW = shipWidth / 2.0
        let halfH = shipHeight / 2.0
        position.x = min(max(position.x, safeMinX + halfW), safeMaxX - halfW)
        position.y = min(max(position.y, safeMinY + halfH), safeMaxY - halfH)

        // Auto-fire bullets
        if autoFire && currentTime - lastFireTime >= fireIntervalSec {
            lastFireTime = currentTime
            let muzzlePos = CGPoint(x: position.x, y: position.y + halfH)
            onShoot(muzzlePos, bulletDamage)
        }
    }
}
